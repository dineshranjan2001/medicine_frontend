import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-mystore-showcategories',
  templateUrl: './shop-mystore-showcategories.component.html',
  styleUrls: ['./shop-mystore-showcategories.component.css']
})
export class ShopMystoreShowcategoriesComponent implements OnInit {
  constructor() { }



  ngOnInit(): void {
  }
  searchMedicine(){

  }
}
