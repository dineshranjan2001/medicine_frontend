import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-profile-contents',
  templateUrl: './shop-profile-contents.component.html',
  styleUrls: ['./shop-profile-contents.component.css']
})
export class ShopProfileContentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
