import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-add-medicines-contents',
  templateUrl: './shop-add-medicines-contents.component.html',
  styleUrls: ['./shop-add-medicines-contents.component.css']
})
export class ShopAddMedicinesContentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
