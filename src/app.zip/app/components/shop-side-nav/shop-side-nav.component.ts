import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-side-nav',
  templateUrl: './shop-side-nav.component.html',
  styleUrls: ['./shop-side-nav.component.css']
})
export class ShopSideNavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
