import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-update-profile-contents',
  templateUrl: './shop-update-profile-contents.component.html',
  styleUrls: ['./shop-update-profile-contents.component.css']
})
export class ShopUpdateProfileContentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
