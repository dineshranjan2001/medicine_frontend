import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-update-medicines-contents',
  templateUrl: './shop-update-medicines-contents.component.html',
  styleUrls: ['./shop-update-medicines-contents.component.css']
})
export class ShopUpdateMedicinesContentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
