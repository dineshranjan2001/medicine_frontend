import { Component, OnInit } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';
import { Shop } from 'src/app/Modelclass/shop';
@Component({
  selector: 'app-shop-sign-up',
  templateUrl: './shop-sign-up.component.html',
  styleUrls: ['./shop-sign-up.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ShopSignUpComponent implements OnInit {

  showOwnerSection:boolean=true;
  showShopSection:boolean=false;
  showRegisterBtn:boolean=false;
  showNextBtnSection:boolean=true;
  showImageIcon:boolean=true;
  showimagePreviewSection:boolean=false;
  checkStatusNumber:Number=0;
  preview:string="";

  nameChecker:RegExp=/^[a-zA-Z ]{3,20}$/;
  emailChecker:RegExp=/^[a-zA-Z0-9._\-]+[@][a-zA-Z.]+[a-z]{2,3}$/;
  phoneChecker:RegExp=/^[6789][0-9]{9}$/;
  addressChecker:RegExp=/^[A-Za-z0-9'\.\-\s\,]+$/;
  passwordChecker:RegExp=/^[A-Za-z0-9]{8}$/;

  constructor() {}

  shop:Shop=new Shop();

  onclick():void{
    if(this.nameChecker.test(this.shop.ownerFirstName)&& this.nameChecker.test(this.shop.ownerLastName) && this.phoneChecker.test(this.shop.ownerPhone)){
        this.showOwnerSection=!this.showOwnerSection;
        this.showShopSection=!this.showShopSection;
        this.showNextBtnSection=!this.showNextBtnSection;
        this.showRegisterBtn=!this.showRegisterBtn;
        (<HTMLInputElement>document.getElementById('body')).style.height='125vh';
        (<HTMLInputElement>document.getElementById('image-section')).style.paddingTop='19%';
    }else if(!this.nameChecker.test(this.shop.ownerFirstName)){
      alert("Please Give Valid Name...");
    }else if(!this.nameChecker.test(this.shop.ownerLastName)){
      alert("Please Give Valid Name...");
    }else if(!this.phoneChecker.test(this.shop.ownerPhone)){
      alert("Please Give Valid Phone Number...");
    }
  }
  backTo():void{
    this.showOwnerSection=!this.showOwnerSection;
    this.showShopSection=!this.showShopSection;
    this.showNextBtnSection=!this.showNextBtnSection;
    this.showRegisterBtn=!this.showRegisterBtn; 
    (<HTMLInputElement>document.getElementById('body')).style.height='100vh';
    (<HTMLInputElement>document.getElementById('image-section')).style.paddingTop='6% !important';
  } 
  selectFile(event: any){
    if(event.target.files){
      var reader=new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload=(event:any)=>{
        this.showImageIcon=!this.showImageIcon;
        this.showimagePreviewSection=!this.showimagePreviewSection;
        this.preview=event.target.result;
      }
    }
  }
  onSubmit():void{
    if(!this.nameChecker.test(this.shop.shopName)){
      alert("Please Give Valid Name");
    }else if(!this.phoneChecker.test(this.shop.shopPhone)){
      alert("Please Give Valid Phone Number...");
    }else if(!this.passwordChecker.test(this.shop.shopPassword)){
      console.log(this.shop.shopPassword);
      alert("Please Give Valid Password...");
    }else if(!this.addressChecker.test(this.shop.shopAddress)){
      alert("Please Give Valid Address...");
    }else if(this.shop.shopPhoto==""||this.shop.shopPhoto==null){
      alert("Please Give Photo...");
    }else{
      console.log(this.shop);
    }
  }
  ngOnInit(): void {
    
  }
 
}
