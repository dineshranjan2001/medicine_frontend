import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-sign-in',
  templateUrl: './shop-sign-in.component.html',
  styleUrls: ['./shop-sign-in.component.css']
})
export class ShopSignInComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
