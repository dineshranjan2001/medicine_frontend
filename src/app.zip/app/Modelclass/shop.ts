export class Shop {
    ownerFirstName!:string;
    ownerLastName!:string;
    ownerPhone!:string;
    shopName!:string;
    shopPhone!:string;
    shopPassword!:string;
    shopPhoto!:any;
    shopUsername!:string;
    shopAddress!:string;
}
