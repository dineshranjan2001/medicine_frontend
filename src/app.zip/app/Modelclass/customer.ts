export class Customer {
    customerFirstName!:string;
    customerLastName!:string;
    customerEmail!:string;
    customerPhone!:string;
    customerPhoto!:string;
    customerAddress!:string;
    customerPassword!:string;
}
